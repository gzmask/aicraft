git add .
git commit -am'minor'
git push
