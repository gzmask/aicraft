texi2pdf aicraft.tex
