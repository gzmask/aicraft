git pull
npm update
