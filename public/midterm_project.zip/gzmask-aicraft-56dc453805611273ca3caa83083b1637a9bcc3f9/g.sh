./make.sh
./aicraft_server.js
