nohup ./aicraft_server.js > /dev/null &
