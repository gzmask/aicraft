/**
 * @fileoverview module name defined
 */

/**
 * @class export name is AICRAFT
 */
var AICRAFT = AICRAFT || {};

if(typeof(exports) !== 'undefined' && exports !== null) {
	exports.AICRAFT = AICRAFT;
};
